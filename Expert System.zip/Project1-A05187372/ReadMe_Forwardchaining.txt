I have used Netbeans IDE to develop and test the code for various test cases.

In terminal go to the folder where it says ForwardChaining to run the forward chaining code.

And then Compile using:
g++ forwardchain.h main.cpp

And then run using:
.\a.exe